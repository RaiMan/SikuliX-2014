Sikuli-1.1.0-Supplemental-Linux
===============================

**** this package needs versions 1.1.0-Beta4 and later --- does not work with earlier versions ****

If you encounter any problems with the bundled libVisionProxy.so, 
then you might try to build it on your Linux/Unix system using this package.

1. put the unzipped stuff in any folder
2. in terminal session cd into that folder

3. run makeVisionProxy
either by
. makeVisionProxy
or by
./makeVisionProxy       (after having made it executable)

4. hopefully you see some compile messages and one link message without any additional error messages
5. if no errors: replace the libVisionProxy.so in your Sikuli setup folder libs with the new one from folder dist
   keep it in a safe place for cases, where you might have to copy it again into a changed libs folder
6. if there are any error messages: ok, you have to solve them ;-) and start again at step 3

--- the prerequisites
- you need a valid g++ installation
- you need a valid Java JDK installation (if there, it is found automatically by the script)
- OpenCV must be installed as dev version* (preferably version 2.4, but at least 2.2)
- Tesseract must be installed as dev version* (must be version 3.0+)
- the command script expects the header files* in /usr/include or /usr/local/include
- on some Linux installations additional dev packages might be needed to satisfy the includes during compile
- if you get any include problems in compile steps, you might have to add/modify -I.... entries in the script
- the command script expects the libraries in /usr/lib or /usr/local/lib (or /usr/lib64 if it exists on the system)

* must be installed as dev version - means, that the installation of the respective package must install the C++ include files in the folders expected by your build enviroment as standard. If this does not work, you have to adjust the script accordingly.

** If none of these paths works (might be the case on late Ubuntu, where OpenCV is preinstalled somewhere else) though the packages are available on your system, you have to evaluate the loader path (see the man pages/help of ld.so on your system).
Another possibility might be, to look into the loader cache (usually at /etc/ld.so.cache).

The script tries to find Java JDK, OpenCV and Tesseract on your system according to the above rules. 
If you get the info, that one of them cannot be found, the build is cancelled. 
Try to repair and run again.

good luck ;-)

********* This e.g. works for Ubuntu and systems using Debian packages ***********
sudo apt-get install openjdk-7-jdk
sudo apt-get install libopencv-dev
sudo apt-get install libtesseract-dev

... and then run makeVisionProxy

----------------------------------------------------

--- upload text for launchpad
ONLY FOR 1.1.0-Beta1+: Having problems with bundled libVisionProxy.so? Try to build it using this package. download - unzip - LOOK into README.txt !!!